﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LMS5.Employee
{
    public partial class Form3EmpRequestsEditControl : UserControl
    {
        private string connectionString = "Data Source=(localdb)\\localDB_1; Initial Catalog=LeaveManagementSystem2; Integrated Security=true";
        private int selectedLeaveRequestID = -1; 

        public Form3EmpRequestsEditControl()
        {
            InitializeComponent();
            FillUserIDTextBox();
            LoadLeaveRequests();
            dgvReq.CellClick += dataGridView_CellClick;
            LoadLeaveTypes();

            dtpStartDate.Value = DateTime.Now;
            dtpEndDate.Value = DateTime.Now;
            dtpStartTime.Value = DateTime.Now;
            dtpEndTime.Value = DateTime.Now;
        }

        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)//populate data when clicking a row
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvReq.Rows.Count)
            {
                DataGridViewRow selectedRow = dgvReq.Rows[e.RowIndex];
                selectedLeaveRequestID = Convert.ToInt32(selectedRow.Cells["LeaveRequestID"].Value); 

                cmbLeaveType.Text = selectedRow.Cells["LeaveType"].Value?.ToString() ?? string.Empty;

                if (DateTime.TryParse(selectedRow.Cells["StartDate"].Value?.ToString(), out DateTime startDate))
                {
                    dtpStartDate.Value = startDate;
                }
                else
                {
                    MessageBox.Show("Invalid start date format.");
                }

                if (DateTime.TryParse(selectedRow.Cells["EndDate"].Value?.ToString(), out DateTime endDate))
                {
                    dtpEndDate.Value = endDate;
                }
                else
                {
                    MessageBox.Show("Invalid end date format.");
                }

                txtReason.Text = selectedRow.Cells["Reason"].Value?.ToString();
                dtpShortLeaveDate.Value = dtpStartDate.Value;
            }
            else
            {
                MessageBox.Show("Please select a valid row.");
            }
        }

        private void LoadLeaveTypes()//populate data into cmb
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT LeaveTypeID, LeaveType FROM LeaveTypes";
                    SqlCommand command = new SqlCommand(query, conn);
                    SqlDataReader reader = command.ExecuteReader();

                    cmbLeaveType.Items.Clear();
                    while (reader.Read())
                    {
                        string leaveType = reader["LeaveType"].ToString();
                        cmbLeaveType.Items.Add(leaveType);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading leave types: " + ex.Message);
                }
            }
        }

        private void FillUserIDTextBox()
        {
            txtUserID.Text = UserSession.LoggedInUserID.ToString();
        }

        private void LoadLeaveRequests()//pop data to dgv
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT lr.LeaveRequestID, lr.StartDate, lr.EndDate, lr.Reason, lt.LeaveType 
                        FROM LeaveRequests2 lr 
                        JOIN LeaveTypes lt ON lr.LeaveTypeID = lt.LeaveTypeID 
                        WHERE lr.UserID = @UserID AND lr.Status = 'Pending'";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    da.SelectCommand.Parameters.AddWithValue("@UserID", UserSession.LoggedInUserID);

                    DataTable dataTable = new DataTable();
                    da.Fill(dataTable);

                    dgvReq.DataSource = dataTable;
                    dgvReq.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading leave requests: " + ex.Message);
                }
            }
        }

        private int GetLeaveTypeId(string leaveType)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT LeaveTypeID FROM LeaveTypes WHERE LeaveType = @LeaveType";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@LeaveType", leaveType);

                conn.Open();
                object result = command.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : -1;
            }
        }

        private bool ValidateInput(out int leaveTypeId, out DateTime startDate, out DateTime endDate, out string reason)
        {
            leaveTypeId = GetLeaveTypeId(cmbLeaveType.Text);
            startDate = dtpStartDate.Value;
            endDate = dtpEndDate.Value;
            reason = txtReason.Text;

            bool isValid = leaveTypeId > 0 && startDate < endDate && !string.IsNullOrWhiteSpace(reason);

            if (!isValid)
            {
                if (leaveTypeId <= 0)
                    MessageBox.Show("Please select a valid leave type.");
                if (startDate >= endDate)
                    MessageBox.Show("Start date must be earlier than end date.");
                if (string.IsNullOrWhiteSpace(reason))
                    MessageBox.Show("Reason cannot be empty.");
            }

            return isValid;
        }

        private bool IsLeaveOverlapping(int userId, DateTime startDate, DateTime endDate, int leaveTypeId)//checking overlapping
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"
                    SELECT COUNT(*) FROM LeaveRequests2
                    WHERE UserID = @UserID 
                    AND LeaveTypeID = @LeaveTypeID 
                    AND LeaveRequestID != @LeaveRequestID  -- Exclude the current leave request
                    AND (StartDate BETWEEN @StartDate AND @EndDate 
                         OR EndDate BETWEEN @StartDate AND @EndDate)";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@UserID", UserSession.LoggedInUserID);
                cmd.Parameters.AddWithValue("@LeaveTypeID", leaveTypeId);
                cmd.Parameters.AddWithValue("@LeaveRequestID", selectedLeaveRequestID); 
                cmd.Parameters.AddWithValue("@StartDate", startDate);
                cmd.Parameters.AddWithValue("@EndDate", endDate);

                int count = (int)cmd.ExecuteScalar();
                return count > 0;
            }
        }

        private void UpdateUserLeaveBalances(int userId, int leaveTypeId, int leaveDays)// update db leave balance table
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"
                    UPDATE LeaveBalance 
                    SET AnnualLeaveBalance = CASE WHEN @LeaveTypeID = 1 THEN AnnualLeaveBalance - @LeaveDays ELSE AnnualLeaveBalance END,
                        CasualLeaveBalance = CASE WHEN @LeaveTypeID = 2 THEN CasualLeaveBalance - @LeaveDays ELSE CasualLeaveBalance END,
                        ShortLeaveBalance = CASE WHEN @LeaveTypeID = 3 THEN ShortLeaveBalance - 1 ELSE ShortLeaveBalance END
                    WHERE UserID = @UserID";
                SqlCommand command = new SqlCommand(query, conn);
                command.Parameters.AddWithValue("@UserID", userId);
                command.Parameters.AddWithValue("@LeaveTypeID", leaveTypeId);
                command.Parameters.AddWithValue("@LeaveDays", leaveDays);

                command.ExecuteNonQuery();
            }
        }

        private void UpdateLeaveRequest(int leaveTypeId, DateTime startDate, DateTime endDate, string reason)//update leave req tabel
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        UPDATE LeaveRequests2 
                        SET LeaveTypeID = @LeaveTypeID, 
                            StartDate = @StartDate, 
                            EndDate = @EndDate, 
                            Reason = @Reason
                        WHERE LeaveRequestID = @LeaveRequestID";

                    SqlCommand command = new SqlCommand(query, conn);
                    command.Parameters.AddWithValue("@LeaveTypeID", leaveTypeId);
                    command.Parameters.AddWithValue("@StartDate", startDate);
                    command.Parameters.AddWithValue("@EndDate", endDate);
                    command.Parameters.AddWithValue("@Reason", reason);
                    command.Parameters.AddWithValue("@LeaveRequestID", selectedLeaveRequestID); 

                    command.ExecuteNonQuery();

                    MessageBox.Show("Leave request updated successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating leave request: " + ex.Message);
                }
            }
        }

 

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (selectedLeaveRequestID == -1)
            {
                MessageBox.Show("Please select a leave request to update.");
                return;
            }

            if (ValidateInput(out int leaveTypeId, out DateTime startDate, out DateTime endDate, out string reason))
            {
                // Check if the updated leave request overlaps with other leave requests
                if (IsLeaveOverlapping(UserSession.LoggedInUserID, startDate, endDate, leaveTypeId))
                {
                    MessageBox.Show("This leave period overlaps with an existing leave request.");
                    return;
                }

                //calculate the number of leave days
                int leaveDays = (endDate - startDate).Days + 1;

                // Update the leave request
                UpdateLeaveRequest(leaveTypeId, startDate, endDate, reason);

                UpdateUserLeaveBalances(UserSession.LoggedInUserID, leaveTypeId, leaveDays);//uPDATE leave balance 

                // Reload leave requests
                LoadLeaveRequests();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            cmbLeaveType.SelectedIndex = -1; // Clear selection
            dtpStartDate.Value = DateTime.Now;
            dtpEndDate.Value = DateTime.Now;
            txtReason.Text = string.Empty;
            dtpStartTime.Value = DateTime.Now;
            dtpEndTime.Value = DateTime.Now;
        }
    }
}
