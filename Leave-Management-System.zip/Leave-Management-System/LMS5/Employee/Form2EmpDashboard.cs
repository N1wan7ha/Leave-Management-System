﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Collections.Specialized.BitVector32;

namespace LMS5.Employee
{
    public partial class Form2EmpDashboard : Sample
    {
        private string connectionString = "Data Source=(localdb)\\localDB_1;" +
                                  "Initial Catalog=LeaveManagementSystem2; Integrated Security=true";

        public Form2EmpDashboard()
        {
            InitializeComponent(); 
            LoadPendingRequestCount();
            LoadLeaveRequests();
            LoadRejectedRequestCount();
            LoadApprovedRequestCount();
        }


        private void LoadApprovedRequestCount() //get approved count
        {
            int approvedCount = 0;

            if (UserSession.LoggedInUserID == null)
            {
                MessageBox.Show("error");
                return;
            }

            string query = "SELECT COUNT(*) FROM LeaveRequests2 WHERE Status = 'Approved' AND UserID = @UserID";

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@UserID", UserSession.LoggedInUserID);

                try
                {
                    con.Open();
                    object result = cmd.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        approvedCount = Convert.ToInt32(result);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading user count: " + ex.Message);
                }
            }

            txtApproved.Text = approvedCount.ToString();
        }



        private void LoadRejectedRequestCount()//reject count
        {
            int rejectCount = 0;

            if (UserSession.LoggedInUserID == null)
            {
                MessageBox.Show("error");
                return;
            }

            string query = "SELECT COUNT(*) FROM LeaveRequests2 WHERE Status = 'Rejected' AND UserID = @UserID";

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@UserID", UserSession.LoggedInUserID);

                try
                {
                    con.Open();
                    object result = cmd.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        rejectCount = Convert.ToInt32(result);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading user count: " + ex.Message);
                }
            }

           txtRejectedReq.Text = rejectCount.ToString();
        }


        private void LoadPendingRequestCount()//pending count
        {
            int pendingCount = 0;

            if (UserSession.LoggedInUserID == null)
            {
                MessageBox.Show("User is not logged in.");
                return;
            }

            string query = "SELECT COUNT(*) FROM LeaveRequests2 WHERE Status = 'Pending' AND UserID = @UserID";

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@UserID", UserSession.LoggedInUserID);

                try
                {
                    con.Open();
                    object result = cmd.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        pendingCount = Convert.ToInt32(result);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading user count: " + ex.Message);
                }
            }

            txtPending.Text = pendingCount.ToString();
        }



        private void LoadLeaveRequests()//get leave req for dgv
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM LeaveRequests2 WHERE UserID = @UserID";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    da.SelectCommand.Parameters.AddWithValue("@UserID", UserSession.LoggedInUserID);

                    DataTable dataTable = new DataTable();
                    da.Fill(dataTable);

                    dgvAllRequests.DataSource = dataTable;
                    dgvAllRequests.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading leave requests: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

    }
}
