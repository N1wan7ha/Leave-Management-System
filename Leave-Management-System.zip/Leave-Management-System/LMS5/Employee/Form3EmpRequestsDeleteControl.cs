﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LMS5.Employee
{
    public partial class Form3EmpRequestsDeleteControl : UserControl
    {
        private string connectionString = "Data Source=(localdb)\\localDB_1; Initial Catalog=LeaveManagementSystem2; Integrated Security=true";

        public Form3EmpRequestsDeleteControl()
        {
            InitializeComponent();
            FillUserIDTextBox();
            LoadLeaveRequests();
            dgvReq.CellClick += dataGridView_CellClick;
            dtpStartDate.Value = DateTime.Now;
            dtpEndDate.Value = DateTime.Now;
            dtpStartTime.Value = DateTime.Now;
            dtpEndTime.Value = DateTime.Now;

        }

        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)//populating data when clck row
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvReq.Rows.Count)
            {
                DataGridViewRow selectedRow = dgvReq.Rows[e.RowIndex];
                cmbLeaveType.Text = selectedRow.Cells["LeaveType"].Value?.ToString() ?? string.Empty;

                if (DateTime.TryParse(selectedRow.Cells["StartDate"].Value?.ToString(), out DateTime startDate))
                {
                    dtpStartDate.Value = startDate;
                }
                else
                {
                    MessageBox.Show("Invalid start date format.");
                }

                if (DateTime.TryParse(selectedRow.Cells["EndDate"].Value?.ToString(), out DateTime endDate))
                {
                    dtpEndDate.Value = endDate;
                }
                else
                {
                    MessageBox.Show("Invalid end date format.");
                }

                txtReason.Text = selectedRow.Cells["Reason"].Value?.ToString();
                dtpShortLeaveDate.Value = dtpStartDate.Value;
            }
            else
            {
                MessageBox.Show("Please select a valid row.");
            }
        }

        private void FillUserIDTextBox()
        {
            txtUserID.Text = UserSession.LoggedInUserID.ToString();
        }

        private void LoadLeaveRequests()//load req to dgv
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT lr.*, lt.LeaveType 
                        FROM LeaveRequests2 lr 
                        JOIN LeaveTypes lt ON lr.LeaveTypeID = lt.LeaveTypeID 
                        WHERE lr.UserID = @UserID AND lr.Status = 'Pending'";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    da.SelectCommand.Parameters.AddWithValue("@UserID", UserSession.LoggedInUserID);

                    DataTable dataTable = new DataTable();
                    da.Fill(dataTable);

                    dgvReq.DataSource = dataTable;
                    dgvReq.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading leave requests: " + ex.Message);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)

        {
            if (dgvReq.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgvReq.SelectedRows[0];

                int leaveRequestId = Convert.ToInt32(selectedRow.Cells["LeaveRequestID"].Value);

                var confirmationResult = MessageBox.Show("Are you sure you want to delete this leave request?", "Confirm Deletion", MessageBoxButtons.YesNo);
                if (confirmationResult == DialogResult.Yes)
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        try
                        {
                            conn.Open();
                            string query = "DELETE FROM LeaveRequests2 WHERE LeaveRequestID = @LeaveRequestID"; //deleteing from db tabel
                            SqlCommand command = new SqlCommand(query, conn);
                            command.Parameters.AddWithValue("@LeaveRequestID", leaveRequestId);

                            int rowsAffected = command.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Leave request deleted successfully.");
                                LoadLeaveRequests(); 
                            }
                            else
                            {
                                MessageBox.Show("No leave request found with the specified ID.");
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error deleting leave request: " + ex.Message);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a leave request to delete.");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            cmbLeaveType.SelectedIndex = -1;
            dtpStartDate.Value = DateTime.Now;
            dtpEndDate.Value = DateTime.Now;
            txtReason.Text = string.Empty;
            dtpStartTime.Value = DateTime.Now;
            dtpEndTime.Value = DateTime.Now;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
