﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LMS5.Employee
{
    public partial class Form3EmpRequests : Sample
    {
        private string connectionString = "Data Source=(localdb)\\localDB_1; Initial Catalog=LeaveManagementSystem2; Integrated Security=true";

        public Form3EmpRequests()
        {
            InitializeComponent();
            LoadLeaveRequests();

            // Ensure UserSession.LoggedInUserID is correctly set before calling DisplayLeaveBalance
            int userId = UserSession.LoggedInUserID; // Assuming this is set somewhere in your application
            DisplayLeaveBalance(userId);
        }

        private void LoadLeaveRequests()//load req to dgv
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM LeaveRequests2 WHERE UserID = @UserID";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    da.SelectCommand.Parameters.AddWithValue("@UserID", UserSession.LoggedInUserID);

                    DataTable dataTable = new DataTable();
                    da.Fill(dataTable);

                    dgvAllReq.DataSource = dataTable;
                    dgvAllReq.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading leave requests: " + ex.Message);
                }
            }
        }

        private void btnAddEmp_Click(object sender, EventArgs e)
        {
            Form3EmpRequestsAddControl form = new Form3EmpRequestsAddControl();
            this.Controls.Add(form);
            form.Dock = DockStyle.Fill;
            form.BringToFront();
        }

        private void DisplayLeaveBalance(int userId)//show leave balances
        {
            string query = "SELECT AnnualLeaveBalance, CasualLeaveBalance, ShortLeaveBalance FROM LeaveBalance WHERE UserID = @UserID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@UserID", userId);

                    try
                    {
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();

                        if (reader.Read()) // Check if there's a result
                        {
                            // Populate the text boxes with the retrieved data
                            txtAnnualLeave.Text = reader["AnnualLeaveBalance"].ToString();
                            txtCasualLeave.Text = reader["CasualLeaveBalance"].ToString();
                            txtShortLeave.Text = reader["ShortLeaveBalance"].ToString();
                        }
                        else
                        {
                            // Handle case where no data is found (optional)
                            MessageBox.Show("No leave balance data found for this user.");
                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle exceptions (e.g., database connection issues)
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Form3EmpRequestsEditControl form3EmpRequestsEdit = new Form3EmpRequestsEditControl();
            this.Controls.Add((form3EmpRequestsEdit));
            form3EmpRequestsEdit.Dock= DockStyle.Fill;
            form3EmpRequestsEdit.BringToFront();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Form3EmpRequestsDeleteControl deleteControl = new Form3EmpRequestsDeleteControl();
            this.Controls.Add((deleteControl));
            deleteControl.Dock= DockStyle.Fill;
            deleteControl.BringToFront();
        }
    }
}
