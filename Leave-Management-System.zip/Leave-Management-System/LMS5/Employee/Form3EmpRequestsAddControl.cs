﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LMS5
{
    public partial class Form3EmpRequestsAddControl : UserControl
    {
        public Form3EmpRequestsAddControl()
        {
            InitializeComponent();
            this.Load += LeaveRequestControl_Load; 
            FillUserIDTextBox();
            dtpStartDate.Value = DateTime.Now;
            dtpEndDate.Value = DateTime.Now;
            dtpStartTime.Value = DateTime.Now;
            dtpEndTime.Value = DateTime.Now;
        }

        private string connectionString = "Data Source=(localdb)\\localDB_1;" +
                                          "Initial Catalog=LeaveManagementSystem2; Integrated Security=true";
        private void FillUserIDTextBox()
        {
            txtUserID.Text = UserSession.LoggedInUserID.ToString();//populate userid 
        }

        private void cmbLeaveType_SelectedIndexChanged(object sender, EventArgs e)//populate cmb with leavetypes
        {
            if (cmbLeaveType.SelectedItem is DataRowView selectedRow)
            {
                string selectedLeaveType = selectedRow["LeaveType"].ToString();

                if (selectedLeaveType == "Annual Leave" || selectedLeaveType == "Casual Leave")
                {
                    dtpStartDate.Enabled = true;
                    dtpEndDate.Enabled = true;
                    dtpStartTime.Enabled = false;
                    dtpEndTime.Enabled = false;
                }
                else if (selectedLeaveType == "Short Leave")
                {
                    dtpStartDate.Enabled = false;
                    dtpEndDate.Enabled = false;
                    dtpStartTime.Enabled = true;
                    dtpEndTime.Enabled = true;
                }
            }
        }

        public void AdjustLeaveBalances(int userId)//calculate the leave balance 1
        {
            DateTime joiningDate = GetEmployeeJoiningDate(userId);

            var leaveBalances = CalculateLeaveAllocation(joiningDate);

            UpdateLeaveBalancesInDatabase(userId, leaveBalances.annualLeave, leaveBalances.casualLeave, leaveBalances.shortLeavePerMonth);
        }

        public DateTime GetEmployeeJoiningDate(int userId)//calculate leave balance 2
        {
            DateTime joiningDate = DateTime.MinValue;
            string query = "SELECT JoiningDate FROM Employees WHERE UserID = @UserID";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@UserID", userId);
                conn.Open();

                object result = cmd.ExecuteScalar();
                if (result != null)
                {
                    joiningDate = Convert.ToDateTime(result);
                }
                conn.Close();
            }
            return joiningDate;
        }

        public (int annualLeave, int casualLeave, int shortLeavePerMonth) CalculateLeaveAllocation(DateTime joiningDate)//calculate leave balance 3
        {
            int totalAnnualLeaves = 14;
            int totalCasualLeaves = 7;
            int shortLeavesPerMonth = 2;

            DateTime currentDate = DateTime.Now;

            // Calculate months left in the current year from the joining date
            int monthsLeft = 12 - joiningDate.Month + 1;

            int adjustedAnnualLeave = (monthsLeft * totalAnnualLeaves) / 12;
            int adjustedCasualLeave = (monthsLeft * totalCasualLeaves) / 12;

            return (adjustedAnnualLeave, adjustedCasualLeave, shortLeavesPerMonth);
        }

        public void UpdateLeaveBalancesInDatabase(int userId, int annualLeave, int casualLeave, int shortLeavePerMonth)// update db table as leave calculated balance 
        {
            string query = @"UPDATE LeaveBalance 
                     SET AnnualLeave = @AnnualLeave, 
                         CasualLeave = @CasualLeave, 
                         ShortLeavePerMonth = @ShortLeavePerMonth
                     WHERE UserID = @UserID";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@AnnualLeave", annualLeave);
                cmd.Parameters.AddWithValue("@CasualLeave", casualLeave);
                cmd.Parameters.AddWithValue("@ShortLeavePerMonth", shortLeavePerMonth);
                cmd.Parameters.AddWithValue("@UserID", userId);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        private void LeaveRequestControl_Load(object sender, EventArgs e)
        {
            var leaveTypes = new Dictionary<int, string>
                {
                    { 1, "Annual Leave" },
                    { 2, "Casual Leave" },
                    { 3, "Short Leave" }
                };

            // get data to cmb
            cmbLeaveType.DataSource = new BindingSource(leaveTypes, null);
            cmbLeaveType.DisplayMember = "Value"; // display by name
            cmbLeaveType.ValueMember = "Key";     // store by id

            cmbLeaveType.SelectedIndex = -1; 

            LoadUserLeaveRequests(UserSession.LoggedInUserID);
        }

        private bool IsLeaveOverlapping(int userId, DateTime startDate, DateTime endDate, int leaveTypeId) //validating overlapping leaves
        {
            DateTime startDateOnly = startDate.Date;
            DateTime endDateOnly = endDate.Date;

            string query = @"
        SELECT COUNT(*) FROM LeaveRequests2
        WHERE UserID = @UserID AND LeaveTypeID = @LeaveTypeID AND
              ((CAST(StartDate AS DATE) <= @EndDate AND CAST(EndDate AS DATE) >= @StartDate) OR
               (CAST(StartDate AS DATE) >= @StartDate AND CAST(StartDate AS DATE) <= @EndDate))";

            try
            {
                using (var conn = new SqlConnection(connectionString))
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserID", userId);
                    cmd.Parameters.AddWithValue("@StartDate", startDateOnly);
                    cmd.Parameters.AddWithValue("@EndDate", endDateOnly);
                    cmd.Parameters.AddWithValue("@LeaveTypeID", leaveTypeId);

                    conn.Open();
                    int count = Convert.ToInt32(cmd.ExecuteScalar());

                    //MessageBox.Show($"Checking overlap: UserID={userId}, StartDate={startDateOnly}, EndDate={endDateOnly}, LeaveTypeID={leaveTypeId}, OverlapCount={count}");

                    return count > 0; 
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error checking overlapping leave: {ex.Message}");
                return true;
            }
        }

        private bool ValidateInput(out int userId, out int leaveTypeId, out DateTime startDate, out DateTime endDate, out string reason)//validating intputs
        {
            userId = 0;
            leaveTypeId = 0;
            startDate = DateTime.MinValue;
            endDate = DateTime.MinValue;
            reason = string.Empty;

            if (!int.TryParse(txtUserID.Text, out userId) ||
                !int.TryParse(cmbLeaveType.SelectedValue?.ToString(), out leaveTypeId) ||
                dtpStartDate.Value == null ||
                dtpEndDate.Value == null ||
                string.IsNullOrWhiteSpace(txtReason.Text))
            {
                MessageBox.Show("Please provide valid input.");
                return false;
            }

            startDate = dtpStartDate.Value;
            endDate = dtpEndDate.Value;
            reason = txtReason.Text;

            return true;
        }

        private void LoadUserLeaveRequests(int userId)//load leave reqs to dgv
        {
            string query = "SELECT * FROM LeaveRequests2 WHERE UserID = @UserID";

            try
            {
                using (var conn = new SqlConnection(connectionString))
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserID", userId); 

                    var da = new SqlDataAdapter(cmd);
                    var dataTable = new DataTable();
                    da.Fill(dataTable);

                    if (dataTable.Rows.Count > 0)
                    {
                        dgvReq.DataSource = dataTable; 
                        dgvReq.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells); 
                    }
                    else
                    {
                        MessageBox.Show("No leave requests found for this user.");
                        dgvReq.DataSource = null; 
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading leave requests: {ex.Message}");
            }
        }

        private bool ValidateLeaveRequest(int userId, LeaveRule leaveRule, DateTime startDate, DateTime endDate, out string validationMessage)//validate req are ok according to rules
        {
            validationMessage = string.Empty;

            TimeSpan leaveDuration = endDate - startDate;

            if (leaveRule.MaxAnnualLeave > 0)
            {
                int annualLeaveUsed = GetUserLeaveUsed(userId, "AnnualLeaveUsed");
                int totalAnnualLeave = leaveRule.MaxAnnualLeave;

                if (startDate < DateTime.Now.AddDays(7)) // Annual leave can be applied up to 7 days in advance
                {
                    validationMessage = "Annual leave can only be applied up to 7 days in advance.";
                    return false;
                }

                if (annualLeaveUsed + leaveDuration.Days > totalAnnualLeave)
                {
                    validationMessage = "Exceeded maximum annual leave limit.";
                    return false;
                }
            }

            if (leaveRule.MaxCasualLeave > 0)
            {
                int casualLeaveUsed = GetUserLeaveUsed(userId, "CasualLeaveUsed");
                int totalCasualLeave = leaveRule.MaxCasualLeave;

                if (casualLeaveUsed + leaveDuration.Days > totalCasualLeave)//exceeded
                {
                    validationMessage = "Exceeded maximum casual leave limit.";
                    return false;
                }
            }

            if (leaveRule.MaxShortLeavesPerMonth > 0)
            {
                int shortLeaveUsed = GetUserLeaveUsed(userId, "ShortLeaveUsed");
                int totalShortLeavesPerMonth = leaveRule.MaxShortLeavesPerMonth;

                // duration for short leave is 1 hour and 30 minutes
                if (leaveDuration.TotalMinutes > leaveRule.ShortLeaveDurationInMinutes)
                {
                    validationMessage = $"Short leave duration should be less than or equal to {leaveRule.ShortLeaveDurationInMinutes} minutes.";
                    return false;
                }

                //leave is requested for upcoming time slots
                if (startDate < DateTime.Now)
                {
                    validationMessage = "Short leave can only be applied for upcoming time slots.";
                    return false;
                }

                //check if maximum per month exceeded
                if (shortLeaveUsed >= totalShortLeavesPerMonth)
                {
                    validationMessage = "Exceeded maximum short leave slots per month.";
                    return false;
                }
            }

            return true;
        }

        private int GetUserLeaveUsed(int userId, string leaveTypeColumn)//used leaves
        {
            string query = $"SELECT {leaveTypeColumn} FROM Users WHERE UserID = @UserID";
            int leaveUsed = 0;

            try
            {
                using (var conn = new SqlConnection(connectionString))
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserID", userId);

                    conn.Open();
                    object result = cmd.ExecuteScalar();
                    if (result != DBNull.Value)
                    {
                        leaveUsed = Convert.ToInt32(result);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error retrieving leave used: {ex.Message}");
            }

            return leaveUsed;
        }

        private void UpdateUserLeaveBalances(int userId, int leaveTypeId, int leaveDays)//update leavebalance
        {
            string columnToUpdate = "";
            int leaveUsed = 0;

            switch (leaveTypeId)
            {
                case 1: // Annual Leave
                    columnToUpdate = "AnnualLeaveUsed";
                    leaveUsed = leaveDays;
                    break;
                case 2: // Casual Leave
                    columnToUpdate = "CasualLeaveUsed";
                    leaveUsed = leaveDays;
                    break;
                case 3: // Short Leave
                    columnToUpdate = "ShortLeaveUsed";
                    leaveUsed = leaveDays;
                    break;
            }

            string query = $"UPDATE Users SET {columnToUpdate} = {columnToUpdate} + @LeaveUsed WHERE UserID = @UserID";

            try
            {
                using (var conn = new SqlConnection(connectionString))
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserID", userId);
                    cmd.Parameters.AddWithValue("@LeaveUsed", leaveUsed);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating leave balances: {ex.Message}");
            }
        }

        private void txtUserID_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(txtUserID.Text, out int userId))
            {
                LoadUserLeaveRequests(userId);
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (!ValidateInput(out int userId, out int leaveTypeId, out DateTime startDate, out DateTime endDate, out string reason))//all filled and validating
            {
                MessageBox.Show("Please provide valid input values.");
                return;
            }

            //checking overlapping leave requests
            if (IsLeaveOverlapping(userId, startDate, endDate, leaveTypeId))
            {
                MessageBox.Show("The leave request overlaps with an existing leave request of the same type. Please choose different dates.");
                return;
            }

            var rulesManager = new LeaveRulesManager();
            LeaveRule leaveRule = rulesManager.GetLeaveRules(leaveTypeId);

            if (leaveRule == null)
            {
                MessageBox.Show("Invalid leave type.");
                return;
            }

            // validating the leave request based on the rules
            if (ValidateLeaveRequest(userId, leaveRule, startDate, endDate, out string validationMessage))
            {
                string query = "INSERT INTO LeaveRequests2 (UserID, LeaveTypeID, StartDate, EndDate, Reason, Status) " +
                               "VALUES (@UserID, @LeaveTypeID, @StartDate, @EndDate, @Reason, 'Pending')";

                try
                {
                    using (var conn = new SqlConnection(connectionString))
                    {
                        var cmd = new SqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@UserID", userId);
                        cmd.Parameters.AddWithValue("@LeaveTypeID", leaveTypeId);
                        cmd.Parameters.AddWithValue("@StartDate", startDate);
                        cmd.Parameters.AddWithValue("@EndDate", endDate);
                        cmd.Parameters.AddWithValue("@Reason", reason);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                    }

                    // Update leave balances
                    UpdateUserLeaveBalances(userId, leaveTypeId, (endDate - startDate).Days + 1); 

                    MessageBox.Show("Leave request submitted successfully and is pending approval.");
                    LoadUserLeaveRequests(userId); 
                }
                catch (SqlException sqlEx)
                {
                    MessageBox.Show($"Database error while submitting leave request: {sqlEx.Message}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error submitting leave request: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show(validationMessage);
            }
        }

        private User GetUser(int userId)
        {
            User user = null;
            string query = "SELECT * FROM Users WHERE UserID = @UserID";

            try
            {
                using (var conn = new SqlConnection(connectionString))
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserID", userId);

                    var da = new SqlDataAdapter(cmd);
                    var dt = new DataTable();
                    da.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        var row = dt.Rows[0];
                        user = new User
                        {
                            UserID = Convert.ToInt32(row["UserID"]),
                            AnnualLeaveUsed = row["AnnualLeaveUsed"] != DBNull.Value ? Convert.ToInt32(row["AnnualLeaveUsed"]) : 0,
                            CasualLeaveUsed = row["CasualLeaveUsed"] != DBNull.Value ? Convert.ToInt32(row["CasualLeaveUsed"]) : 0,
                            ShortLeaveUsed = row["ShortLeaveUsed"] != DBNull.Value ? Convert.ToInt32(row["ShortLeaveUsed"]) : 0
                        };
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error retrieving user data: {ex.Message}");
            }

            return user;
        }

        public class LeaveRulesManager//following rules from leaveRules table
        {
            private readonly string connectionString = "Data Source=(localdb)\\localDB_1;" +
                                                      "Initial Catalog=LeaveManagementSystem2; Integrated Security=true";

            public LeaveRule GetLeaveRules(int leaveTypeId)
            {
                string query = "SELECT * FROM LeaveRules WHERE LeaveTypeID = @LeaveTypeID";
                LeaveRule leaveRule = null;

                try
                {
                    using (var conn = new SqlConnection(connectionString))
                    using (var cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@LeaveTypeID", leaveTypeId);

                        conn.Open();
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                leaveRule = new LeaveRule
                                {
                                    MaxAnnualLeave = reader.IsDBNull(reader.GetOrdinal("MaxAnnualLeave")) ? 0 : reader.GetInt32(reader.GetOrdinal("MaxAnnualLeave")),
                                    MaxCasualLeave = reader.IsDBNull(reader.GetOrdinal("MaxCasualLeave")) ? 0 : reader.GetInt32(reader.GetOrdinal("MaxCasualLeave")),
                                    MaxShortLeavesPerMonth = reader.IsDBNull(reader.GetOrdinal("MaxShortLeavesPerMonth")) ? 0 : reader.GetInt32(reader.GetOrdinal("MaxShortLeavesPerMonth")),
                                    ShortLeaveDurationInMinutes = reader.IsDBNull(reader.GetOrdinal("ShortLeaveDurationInMinutes")) ? 0 : reader.GetInt32(reader.GetOrdinal("ShortLeaveDurationInMinutes"))
                                };
                            }
                            else
                            {
                                MessageBox.Show("No leave rules found for the specified LeaveTypeID.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error retrieving leave rules: {ex.Message}");
                }

                return leaveRule;
            }
        }

        public class LeaveRule
        {
            public int MaxAnnualLeave { get; set; }
            public int MaxCasualLeave { get; set; }
            public int MaxShortLeavesPerMonth { get; set; }
            public int ShortLeaveDurationInMinutes { get; set; }
        }

        public class User
        {
            public int UserID { get; set; }
            public int AnnualLeaveUsed { get; set; }
            public int CasualLeaveUsed { get; set; }
            public int ShortLeaveUsed { get; set; }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            cmbLeaveType.SelectedIndex = -1; 
            dtpStartDate.Value = DateTime.Now;
            dtpEndDate.Value = DateTime.Now;
            txtReason.Text = string.Empty;
            dtpStartTime.Value = DateTime.Now;
            dtpEndTime.Value = DateTime.Now;

        }
    }
}