﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LMS5.Employee
{

    public partial class Form1EmpMain : Sample
    {
        private string connectionString = "Data Source=(localdb)\\localDB_1;" +
                          "Initial Catalog=LeaveManagementSystem2; Integrated Security=true";
        public Form1EmpMain()
        {
            InitializeComponent();
            LoadJobTitle();
            LoadUserName();
        }

        private void AddControl(Form Femp)
        {
            CenterPanel.Controls.Clear();
            Femp.TopLevel = false;
            Femp.Dock = DockStyle.Fill;
            CenterPanel.Controls.Add(Femp);
            Femp.Show();
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            AddControl(new Form2EmpDashboard());

        }


        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1Login form1Login = new Form1Login();
            form1Login.Show();
            this.Close();
        }

        private void btnRequest_Click(object sender, EventArgs e)
        {
            AddControl(new Form3EmpRequests());
        }

        private void Form1EmpMain_Load(object sender, EventArgs e)
        {
            btnMax.PerformClick();
        }

        private void btnRules_Click(object sender, EventArgs e)
        {
            AddControl(new Form4EmpRules());
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoadJobTitle() //load user's position
        {
            int loggedInUserID = UserSession.LoggedInUserID;

            if (loggedInUserID != -1) 
            {
                string query = "SELECT Position FROM Users WHERE UserID = @UserID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@UserID", loggedInUserID);

                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();

                        if (reader.Read())
                        {
                            string jobTitle = reader["Position"].ToString();

                            labelJob.Text = jobTitle;
                        }
                        else
                        {
                            MessageBox.Show("User not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("No user is logged in.");
            }
        }

        private void LoadUserName() //get user's name
        {
            int loggedInUserID = UserSession.LoggedInUserID;

            if (loggedInUserID != -1) 
            {
                string query = "SELECT FullName FROM Users WHERE UserID = @UserID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@UserID", loggedInUserID);

                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();

                        if (reader.Read())
                        {
                            string jobTitle = reader["FullName"].ToString();

                            labelUsername.Text = jobTitle;
                        }
                        else
                        {
                            MessageBox.Show("User not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("No user is logged in.");
            }
        }

    }
}
