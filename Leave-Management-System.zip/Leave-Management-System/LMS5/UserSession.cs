﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LMS5
{
    internal class UserSession
    {
        public static int LoggedInUserID { get; set; } = -1;

    }
}
