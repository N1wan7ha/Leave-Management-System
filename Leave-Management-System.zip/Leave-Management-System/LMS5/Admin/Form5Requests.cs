﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LMS5
{
    public partial class Form5Requests : Sample
    {
        private string connectionString = "Data Source=(localdb)\\localDB_1;" +
                                  "Initial Catalog=LeaveManagementSystem2; Integrated Security=true";

        public Form5Requests()
        {
            InitializeComponent();
            this.Load += new System.EventHandler(this.Form5Requests_Load);
        }

        private void Form5Requests_Load(object sender, EventArgs e)
        {
            MainClass mainClass = new MainClass();

            LoadLeaveRequests();
            dgvPendingRequests.CellClick += dataGridView_CellClick;
            int pendingCount = mainClass.LoadPendingReqCount();
            int approvedCount = mainClass.LoadApprovedReqCount();
            int rejectedCount = mainClass.LoadRejectedReqCount();

            //calling mainclass to get data
            txtPendingReq.Text = pendingCount.ToString();
            txtApprovedReq.Text = approvedCount.ToString();
            txtRejectedReq.Text = rejectedCount.ToString();
        }

        public void LoadLeaveRequests()//population data to dgv
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM LeaveRequests2";

                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    da.Fill(dataTable);

                    dgvPendingRequests.DataSource = dataTable;
                    dgvPendingRequests.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading leave requests: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        public void UpdateLeaveRequestStatus(int leaveRequestId, string status, string adminComment)//status updating
        {
            string updateQuery = "UPDATE LeaveRequests2 " +
                                 "SET Status = @Status, ApprovedAt = GETDATE(), AdminComment = @AdminComment " +
                                 "WHERE LeaveRequestID = @LeaveRequestID";

            string insertAdminActionQuery = "INSERT INTO AdminActions (AdminID, LeaveRequestID, Action, Comment) " +
                                            "VALUES (@AdminID, @LeaveRequestID, @Action, @Comment)";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    using (SqlTransaction transaction = conn.BeginTransaction())
                    {
                        using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn, transaction))
                        {
                            updateCmd.Parameters.AddWithValue("@Status", status);
                            updateCmd.Parameters.AddWithValue("@AdminComment", adminComment);
                            updateCmd.Parameters.AddWithValue("@LeaveRequestID", leaveRequestId);
                            updateCmd.ExecuteNonQuery();
                        }

                        using (SqlCommand insertCmd = new SqlCommand(insertAdminActionQuery, conn, transaction))
                        {
                            insertCmd.Parameters.AddWithValue("@AdminID", UserSession.LoggedInUserID); // Get Admin ID from session
                            insertCmd.Parameters.AddWithValue("@LeaveRequestID", leaveRequestId);
                            insertCmd.Parameters.AddWithValue("@Action", status);
                            insertCmd.Parameters.AddWithValue("@Comment", adminComment);
                            insertCmd.ExecuteNonQuery();
                        }

                        if (status == "Approved")
                        {
                            AdjustLeaveBalance(conn, transaction, leaveRequestId);
                        }

                        transaction.Commit();
                    }
                }

                MessageBox.Show($"Leave request {status.ToLower()} and logged successfully.");
                LoadLeaveRequests();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating leave request status: {ex.Message}");
            }
        }

        private void AdjustLeaveBalance(SqlConnection conn, SqlTransaction transaction, int leaveRequestId)
        {
            string getLeaveDetailsQuery = "SELECT UserID, LeaveTypeID, DATEDIFF(day, StartDate, EndDate) + 1 AS LeaveDays FROM LeaveRequests2 WHERE LeaveRequestID = @LeaveRequestID";

            using (SqlCommand cmd = new SqlCommand(getLeaveDetailsQuery, conn, transaction))
            {
                cmd.Parameters.AddWithValue("@LeaveRequestID", leaveRequestId);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        int userID = reader.GetInt32(0);
                        int leaveTypeID = reader.GetInt32(1); 
                        int leaveDays = reader.GetInt32(2);

                        reader.Close();

                        string updateBalanceQuery = "";
                        string getBalanceQuery = "";

                        switch (leaveTypeID)
                        {
                            case 1: // Annual Leave
                                getBalanceQuery = "SELECT AnnualLeaveBalance FROM LeaveBalance WHERE UserID = @UserID";
                                updateBalanceQuery = "UPDATE LeaveBalance SET AnnualLeaveBalance = AnnualLeaveBalance - @LeaveDays WHERE UserID = @UserID";
                                break;
                            case 2: // Casual Leave
                                getBalanceQuery = "SELECT CasualLeaveBalance FROM LeaveBalance WHERE UserID = @UserID";
                                updateBalanceQuery = "UPDATE LeaveBalance SET CasualLeaveBalance = CasualLeaveBalance - @LeaveDays WHERE UserID = @UserID";
                                break;
                            case 3: // Short Leave (assuming 1 short leave = 1 slot, so reduce by 1)
                                getBalanceQuery = "SELECT ShortLeaveBalance FROM LeaveBalance WHERE UserID = @UserID";
                                updateBalanceQuery = "UPDATE LeaveBalance SET ShortLeaveBalance = ShortLeaveBalance - 1 WHERE UserID = @UserID";
                                leaveDays = 1; // Force leaveDays to 1 for short leave
                                break;
                        }

                        using (SqlCommand getBalanceCmd = new SqlCommand(getBalanceQuery, conn, transaction))
                        {
                            getBalanceCmd.Parameters.AddWithValue("@UserID", userID);
                            int currentBalance = Convert.ToInt32(getBalanceCmd.ExecuteScalar());

                            // Check if the current balance is sufficient before updating
                            if (currentBalance >= leaveDays)
                            {
                                using (SqlCommand updateBalanceCmd = new SqlCommand(updateBalanceQuery, conn, transaction))
                                {
                                    updateBalanceCmd.Parameters.AddWithValue("@LeaveDays", leaveDays);
                                    updateBalanceCmd.Parameters.AddWithValue("@UserID", userID);
                                    updateBalanceCmd.ExecuteNonQuery();
                                }
                            }
                            else
                            {
                                throw new Exception("Insufficient leave balance.");
                            }
                        }
                    }
                }
            }
        }
        private string GetFullNameByUserID(int userID)
        {
            string fullName = "";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT FullName FROM Users WHERE UserID = @UserID";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@UserID", userID);
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        fullName = reader["FullName"].ToString();
                    }
                }
            }
            return fullName;
        }

        private void dataGridView_CellClick(object sender, DataGridViewCellEventArgs e)//when clicking pop the data
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dgvPendingRequests.Rows[e.RowIndex];

                txtEmpLeaveType.Text = selectedRow.Cells["LeaveTypeID"].Value.ToString();
                txtStartDate.Text = selectedRow.Cells["StartDate"].Value.ToString();
                txtEndDate.Text = selectedRow.Cells["EndDate"].Value.ToString();
                txtEmpReason.Text = selectedRow.Cells["Reason"].Value.ToString();

                int userID = Convert.ToInt32(selectedRow.Cells["UserID"].Value);
                txtEmpFullName.Text = GetFullNameByUserID(userID);

                txtAdComment.Text = string.Empty;
            }
        }


        private bool IsLeaveOverlapping(SqlConnection conn, SqlTransaction transaction, int leaveRequestId)//check overlapping
        {
            string getLeaveDetailsQuery = "SELECT UserID, StartDate, EndDate FROM LeaveRequests2 WHERE LeaveRequestID = @LeaveRequestID";
            DateTime startDate = DateTime.MinValue;
            DateTime endDate = DateTime.MinValue;
            int userID = 0;
            int departmentID = 0;

            using (SqlCommand cmd = new SqlCommand(getLeaveDetailsQuery, conn, transaction))
            {
                cmd.Parameters.AddWithValue("@LeaveRequestID", leaveRequestId);
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        userID = reader.GetInt32(0);
                        startDate = reader.GetDateTime(1);
                        endDate = reader.GetDateTime(2);
                    }
                }
            }
            //checking intercepting with other leave with same department
            string getDepartmentQuery = "SELECT DepartmentID FROM Users WHERE UserID = @UserID";
            using (SqlCommand cmd = new SqlCommand(getDepartmentQuery, conn, transaction))
            {
                cmd.Parameters.AddWithValue("@UserID", userID);
                departmentID = Convert.ToInt32(cmd.ExecuteScalar());
            }

            string checkOverlapQuery = @"
        SELECT COUNT(*)
        FROM LeaveRequests2 LR
        INNER JOIN Users U ON LR.UserID = U.UserID
        WHERE U.DepartmentID = @DepartmentID
        AND LR.Status = 'Approved'
        AND (
            (@StartDate BETWEEN LR.StartDate AND LR.EndDate) OR
            (@EndDate BETWEEN LR.StartDate AND LR.EndDate) OR
            (LR.StartDate BETWEEN @StartDate AND @EndDate)
        )";

            using (SqlCommand checkCmd = new SqlCommand(checkOverlapQuery, conn, transaction))
            {
                checkCmd.Parameters.AddWithValue("@DepartmentID", departmentID);
                checkCmd.Parameters.AddWithValue("@StartDate", startDate);
                checkCmd.Parameters.AddWithValue("@EndDate", endDate);
                int overlapCount = Convert.ToInt32(checkCmd.ExecuteScalar());

                return overlapCount > 0;
            }
        }

        private void btnApprove_Click(object sender, EventArgs e)
        {
            if (dgvPendingRequests.SelectedRows.Count > 0)
            {
                try
                {
                    int leaveRequestId = Convert.ToInt32(dgvPendingRequests.SelectedRows[0].Cells["LeaveRequestID"].Value);

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        using (SqlTransaction transaction = conn.BeginTransaction())
                        {
                            // Check for overlapping leave requests
                            if (IsLeaveOverlapping(conn, transaction, leaveRequestId))
                            {
                                MessageBox.Show("Leave request overlaps with an existing approved leave request in the department. Approval denied.");
                                return; // Exit the method if there is an overlap
                            }

                            //if no overlap is found
                            UpdateLeaveRequestStatus(leaveRequestId, "Approved", txtAdComment.Text);
                            transaction.Commit(); 
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error approving leave request: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Please select a leave request to approve.");
            }
        }

        private void btnReject_Click(object sender, EventArgs e)
        {
            if (dgvPendingRequests.SelectedRows.Count > 0)
            {
                try
                {
                    int leaveRequestId = Convert.ToInt32(dgvPendingRequests.SelectedRows[0].Cells["LeaveRequestID"].Value);
                    UpdateLeaveRequestStatus(leaveRequestId, "Rejected", txtAdComment.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error rejecting leave request: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Please select a leave request to reject.");
            }
        }
    }
}
