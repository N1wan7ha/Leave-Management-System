﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LMS5
{
    public partial class Form4EmployeeAddControl : UserControl
    {
        string connectionString = "Data Source=(localdb)\\localDB_1;" +
                                  "Initial Catalog=LeaveManagementSystem2; Integrated Security=true";

        public Form4EmployeeAddControl()
        {
            InitializeComponent();
            LoadDepartmentComboBox();
            txtEmpNum.Text = GetNextEmployeeNumber();
        }

        private void LoadDepartmentComboBox()
        {
            string query = "SELECT DepartmentID, DepartmentName FROM [LeaveManagementSystem2].[dbo].[Departments]";

            DataTable departmentTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);

                    connection.Open();
                    adapter.Fill(departmentTable);

                    cmbDepartment.DataSource = departmentTable;
                    cmbDepartment.DisplayMember = "DepartmentName";  
                    cmbDepartment.ValueMember = "DepartmentID";      

                    cmbDepartment.SelectedIndex = -1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading departments: " + ex.Message);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtFullName.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtPosition.Text = string.Empty;
            txtPassword.Text = string.Empty;
            cmbRole.SelectedIndex = -1;
            cmbDepartment.SelectedIndex = -1;
            dtpJoiningDate.Value = DateTime.Now;
            txtEmpNum.Text = string.Empty;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string FullName = txtFullName.Text;
            string EmailAddress = txtEmail.Text;
            string Position = txtPosition.Text;
            string DepartmentName = cmbDepartment.Text;
            int DepartmentID = Convert.ToInt32(cmbDepartment.SelectedValue); 
            DateTime DateOfJoining = dtpJoiningDate.Value;
            string Password = txtPassword.Text;
            string Role = cmbRole.Text;

            // Generate the next available Employee Number
            string EmployeeNumber = GetNextEmployeeNumber();
            txtEmpNum.Text = EmployeeNumber;

            DateTime adjustedJoiningDate = RoundJoiningDate(DateOfJoining);

            string sqlCommand = "INSERT INTO Users (FullName, EmailAddress, Position, DepartmentName, DepartmentID, JoiningDate, Password, Role, EmployeeNumber) " +
                                "OUTPUT INSERTED.UserID " + 
                                "VALUES (@FullName, @Email, @Position, @DepartmentName, @DepartmentID, @JoiningDate, @Password, @Role, @EmployeeNumber)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand command = new SqlCommand(sqlCommand, connection);

                    command.Parameters.AddWithValue("@EmployeeNumber", EmployeeNumber);
                    command.Parameters.AddWithValue("@FullName", FullName);
                    command.Parameters.AddWithValue("@Email", EmailAddress);
                    command.Parameters.AddWithValue("@Position", Position);
                    command.Parameters.AddWithValue("@DepartmentName", DepartmentName);  
                    command.Parameters.AddWithValue("@DepartmentID", DepartmentID);    
                    command.Parameters.AddWithValue("@JoiningDate", adjustedJoiningDate);
                    command.Parameters.AddWithValue("@Password", Password);
                    command.Parameters.AddWithValue("@Role", Role);

                    connection.Open();

                    int newUserId = (int)command.ExecuteScalar();

                    CalculateAndInsertLeaveBalance(newUserId, adjustedJoiningDate, connection);

                    // Insert into the Roster table
                    string rosterSqlCommand = "INSERT INTO Roster (UserID, StartTime, EndTime, DaysOfWeek, CreatedAt) " +
                                               "VALUES (@UserID, @StartTime, @EndTime, @DaysOfWeek, GETDATE())";

                    using (SqlCommand rosterCommand = new SqlCommand(rosterSqlCommand, connection))
                    {
                        rosterCommand.Parameters.AddWithValue("@UserID", newUserId);
                        rosterCommand.Parameters.AddWithValue("@StartTime", /* default start time, e.g., 9 AM */ new TimeSpan(9, 0, 0));
                        rosterCommand.Parameters.AddWithValue("@EndTime", /* default end time, e.g., 5 PM */ new TimeSpan(17, 0, 0));
                        rosterCommand.Parameters.AddWithValue("@DaysOfWeek", "Mon,Tue,Wed,Thu,Fri"); // Default to all weekdays

                        rosterCommand.ExecuteNonQuery(); // Execute the insert for the Roster table
                    }

                    MessageBox.Show("Employee added successfully with leave balances and roster!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        // Method to adjust the joining date (rounding logic)
        private DateTime RoundJoiningDate(DateTime selectedDate)
        {
            if (selectedDate.Day < 15)
            {
                // If day is before the 15th, round to 1st of the same month
                return new DateTime(selectedDate.Year, selectedDate.Month, 1);
            }
            else
            {
                // If day is after the 15th, round to 1st of the next month
                return new DateTime(selectedDate.Year, selectedDate.Month + 1, 1);
            }
        }

        // Method to calculate and insert leave balances
        private void CalculateAndInsertLeaveBalance(int userId, DateTime joiningDate, SqlConnection connection)
        {
            // Calculate remaining months from the joining date till the end of the year
            int remainingMonths = 12 - joiningDate.Month + 1;

            // Calculate pro-rata leave entitlements based on remaining months
            int annualLeave = (remainingMonths * 14) / 12;  // Pro-rated annual leave (14 days a year)
            int casualLeave = (remainingMonths * 7) / 12;   // Pro-rated casual leave (7 days a year)
            int shortLeave = remainingMonths * 2;           // Short leave (2 slots per month)

            // Insert leave balances into LeaveBalance table
            string leaveBalanceQuery = "INSERT INTO LeaveBalance (UserID, AnnualLeaveBalance, CasualLeaveBalance, ShortLeaveBalance) " +
                                       "VALUES (@UserID, @AnnualLeave, @CasualLeave, @ShortLeave)";

            SqlCommand leaveCommand = new SqlCommand(leaveBalanceQuery, connection);
            leaveCommand.Parameters.AddWithValue("@UserID", userId);
            leaveCommand.Parameters.AddWithValue("@AnnualLeave", annualLeave);
            leaveCommand.Parameters.AddWithValue("@CasualLeave", casualLeave);
            leaveCommand.Parameters.AddWithValue("@ShortLeave", shortLeave);

            leaveCommand.ExecuteNonQuery();
        }

        private string GetNextEmployeeNumber()
        {
            string nextEmpNum = "EMP001"; 

            // find maximum existing EmployeeNumber
            string query = "SELECT MAX(EmployeeNumber) FROM Users WHERE EmployeeNumber LIKE 'EMP%'";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    var result = command.ExecuteScalar();

                    if (result != DBNull.Value)
                    {
                        string maxEmpNum = (string)result;

                        int currentNum = int.Parse(maxEmpNum.Substring(3));
                        currentNum++; 

                        nextEmpNum = "EMP" + currentNum.ToString("D3"); // Format "EMPXXX"
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving employee number: " + ex.Message);
                }
            }

            return nextEmpNum;
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
