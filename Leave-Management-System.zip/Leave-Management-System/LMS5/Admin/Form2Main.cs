﻿using LMS5.Admin;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Collections.Specialized.BitVector32;

namespace LMS5
{
    public partial class Form2Main : Sample

    {
        private string connectionString = "Data Source=(localdb)\\localDB_1;" +
                          "Initial Catalog=LeaveManagementSystem2; Integrated Security=true";

        public Form2Main()
        {
            InitializeComponent();
            LoadJobTitle();
            LoadUserName();
        }

        private void Form2Main_Load(object sender, EventArgs e)
        {
            btnMax.PerformClick();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void AddControl(Form F)
        {
            CenterPanel.Controls.Clear();
            F.TopLevel = false;
            F.Dock = DockStyle.Fill;
            CenterPanel.Controls.Add(F);
            F.Show();
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            AddControl(new Form3Dashboard());
        }

        private void btnEmployee_Click(object sender, EventArgs e)
        {
            AddControl(new Form4Employee());
        }

        private void btnRequest_Click(object sender, EventArgs e)
        {
            AddControl(new Form5Requests());

        }

        private void btnType_Click(object sender, EventArgs e)
        {
            AddControl(new Form6LeaveTypes());

        }

        private void btnDep_Click(object sender, EventArgs e)
        {
            AddControl(new Form7Departments());

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1Login form1Login = new Form1Login();
            form1Login.Show();
            this.Close();

            UserSession.LoggedInUserID = -1; 
            //MessageBox.Show("Logged out successfully!");

        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            AddControl(new Form8Reports());
        }

        private void LoadJobTitle()//get posisiton
        {
            int loggedInUserID = UserSession.LoggedInUserID;

            if (loggedInUserID != -1) 
            {
                string query = "SELECT Position FROM Users WHERE UserID = @UserID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@UserID", loggedInUserID);

                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();

                        if (reader.Read())
                        {
                            string jobTitle = reader["Position"].ToString();
                            labelJob.Text = jobTitle;
                        }
                        else
                        {
                            MessageBox.Show("User not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("No user is logged in.");
            }
        }

        private void LoadUserName()//get name
        {
            int loggedInUserID = UserSession.LoggedInUserID;

            if (loggedInUserID != -1)
            {
                string query = "SELECT FullName FROM Users WHERE UserID = @UserID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@UserID", loggedInUserID);

                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();

                        if (reader.Read())
                        {
                            string jobTitle = reader["FullName"].ToString();

                            labelUsername.Text = jobTitle;
                        }
                        else
                        {
                            MessageBox.Show("User not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("No user is logged in.");
            }
        }

    }
}
