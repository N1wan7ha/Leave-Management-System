﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LMS5.Admin
{
    public partial class Form4EmployeeDeleteControl : UserControl
    {
        string connectionString = "Data Source=(localdb)\\localDB_1;" +
                                  "Initial Catalog=LeaveManagementSystem2; Integrated Security=true";

        public Form4EmployeeDeleteControl()
        {
            InitializeComponent();
            LoadEmployeeData();
            dgvEmp.CellClick += DgvEmp_CellClick;
            LoadDepartmentComboBox();
            dtpJoiningDate.Value = DateTime.Now;
        }

        private void LoadDepartmentComboBox()
        {
            string query = "SELECT DepartmentID, DepartmentName FROM [LeaveManagementSystem2].[dbo].[Departments]";
            DataTable departmentTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);

                    connection.Open();
                    adapter.Fill(departmentTable);

                    cmbDepartmentEdit.DataSource = departmentTable;
                    cmbDepartmentEdit.DisplayMember = "DepartmentName";
                    cmbDepartmentEdit.ValueMember = "DepartmentID";   

                    cmbDepartmentEdit.SelectedIndex = -1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading departments: " + ex.Message);
                }
            }
        }

        private void LoadEmployeeData()//get data to dgv
        {
            string query = "SELECT TOP (1000) u.UserID, u.FullName, u.EmailAddress, u.Position, " +
                           "d.DepartmentName, u.JoiningDate, u.Role, u.DepartmentID " + 
                           "FROM [LeaveManagementSystem2].[dbo].[Users] u " +
                           "LEFT JOIN [LeaveManagementSystem2].[dbo].[Departments] d ON u.DepartmentID = d.DepartmentID"; 

            DataTable employeeTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);

                    connection.Open();
                    adapter.Fill(employeeTable);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading employee data: " + ex.Message);
                }
            }
            dgvEmp.DataSource = employeeTable;

            dgvEmp.Columns["UserID"].HeaderText = "User ID";
            dgvEmp.Columns["FullName"].HeaderText = "Full Name";
            dgvEmp.Columns["EmailAddress"].HeaderText = "Email Address";
            dgvEmp.Columns["Position"].HeaderText = "Position";
            dgvEmp.Columns["DepartmentName"].HeaderText = "Department Name";
            dgvEmp.Columns["JoiningDate"].HeaderText = "Joining Date";
            dgvEmp.Columns["Role"].HeaderText = "Role";
        }

        private void DgvEmp_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvEmp.Rows[e.RowIndex];

                txtFullName.Text = row.Cells["FullName"].Value.ToString();
                txtEmail.Text = row.Cells["EmailAddress"].Value.ToString();
                txtPosition.Text = row.Cells["Position"].Value.ToString();
                cmbRole.SelectedItem = row.Cells["Role"].Value.ToString();

                cmbDepartmentEdit.SelectedValue = row.Cells["DepartmentID"].Value;

                dtpJoiningDate.Value = Convert.ToDateTime(row.Cells["JoiningDate"].Value);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void ClearFields()
        {
            txtFullName.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtPosition.Text = string.Empty;
            cmbRole.SelectedIndex = -1;
            cmbDepartmentEdit.SelectedIndex = -1;
            dtpJoiningDate.Value = DateTime.Now;
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (dgvEmp.CurrentRow == null)
            {
                MessageBox.Show("Please select an employee to delete.");
                return;
            }

            int userId = Convert.ToInt32(dgvEmp.CurrentRow.Cells["UserID"].Value);

            var confirmResult = MessageBox.Show("Are you sure you want to delete this employee?",
                                                 "Confirm Delete",
                                                 MessageBoxButtons.YesNo,
                                                 MessageBoxIcon.Warning);
            if (confirmResult == DialogResult.Yes)
            {
                string query = "DELETE FROM [LeaveManagementSystem2].[dbo].[Users] WHERE UserID = @UserID";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@UserID", userId);

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Employee deleted successfully.");
                            LoadEmployeeData(); 
                            ClearFields();
                        }
                        else
                        {
                            MessageBox.Show("Deletion failed. Please try again.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error deleting employee: " + ex.Message);
                    }
                }
            }
        }
    }
}
