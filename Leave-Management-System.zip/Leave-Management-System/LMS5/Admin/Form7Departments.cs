﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LMS5
{
    public partial class Form7Departments : Sample
    {
        public Form7Departments()
        {
            InitializeComponent();
        }

        private void Form7Departments_Load(object sender, EventArgs e)
        {
            this.departmentsTableAdapter.Fill(this.leaveManagementSystem2DataSet3.Departments);
            MainClass mainClass = new MainClass();

            int DepCount = mainClass.LoadDepCount();
            int userCount = mainClass.LoadUserCount();


            txtDep.Text = DepCount.ToString();
            txtTotalEmp.Text = userCount.ToString();
        }
    }
}
