﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LMS5
{
    public partial class Form3Dashboard : Sample
    {
        private string connectionString = "Data Source=(localdb)\\localDB_1;" +
                                  "Initial Catalog=LeaveManagementSystem2; Integrated Security=true";

        public Form3Dashboard()
        {
            InitializeComponent();
            this.Load += Form3Dashboard_Load;
            
        }

        private void Form3Dashboard_Load(object sender, EventArgs e)
        {
            this.leaveRequests2TableAdapter.Fill(this.leaveManagementSystem2DataSet1.LeaveRequests2);
            MainClass mainClass = new MainClass();
            int pendingCount = mainClass.LoadPendingReqCount();
            int approvedCount = mainClass.LoadApprovedReqCount();
            int userCount = mainClass.LoadUserCount();

            //get data by calling mainclass
            txtPendingReq.Text = pendingCount.ToString();
            txtApprovedReq.Text = approvedCount.ToString();
            txtTotalEmp.Text = userCount.ToString();

            
        }

    }
}
