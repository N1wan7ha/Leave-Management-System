﻿using LMS5.Admin;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LMS5
{
    public partial class Form4Employee : Sample
    {
        string connectionString = "Data Source=(localdb)\\localDB_1;" +
                          "Initial Catalog=LeaveManagementSystem2; Integrated Security=true";

        public Form4Employee()
        {
            InitializeComponent();
            this.Load += new System.EventHandler(this.Form4Employee_Load);
            LoadUserData();
        }
        private void Form4Employee_Load(object sender, EventArgs e)
        {
        }

        private void btnAddEmp_Click(object sender, EventArgs e)
        {
            Form4EmployeeAddControl form = new Form4EmployeeAddControl();
            this.Controls.Add(form);
            form.Dock = DockStyle.Fill;
            form.BringToFront();
            LoadUserData();
        }

        private void LoadUserData()//get data into dgv
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT EmployeeNumber, FullName, EmailAddress, Position, DepartmentName, JoiningDate, Password, AnnualLeaveUsed, CasualLeaveUsed, ShortLeaveUsed, Role FROM Users;\r\n";
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvEmployees.DataSource = dt;
                    dgvEmployees.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while loading user data: " + ex.Message);
                }

                finally
                {
                    conn.Close();
                }

            }

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            Form4EmployeeEditControl formEdit = new Form4EmployeeEditControl();
            this.Controls.Add(formEdit);
            formEdit.Dock = DockStyle.Fill;
            formEdit.BringToFront();
            LoadUserData();
        }

        private void guna2Button2_Click(object sender, EventArgs e)
        {
            Form4EmployeeDeleteControl deleteControl = new Form4EmployeeDeleteControl();
            this.Controls.Add(deleteControl);
            deleteControl.Dock = DockStyle.Fill;
            deleteControl.BringToFront();
            LoadUserData();
        }

        private void Form4Employee_Load_1(object sender, EventArgs e)
        {
            this.usersTableAdapter1.Fill(this.leaveManagementSystem2DataSet9.Users);

        }

        private void btnRoaster_Click(object sender, EventArgs e)
        {
            Form4EmpRoster form4EmpRoaster = new Form4EmpRoster();
            this.Controls.Add(form4EmpRoaster);
            form4EmpRoaster.Dock = DockStyle.Fill;
            form4EmpRoaster.BringToFront();
            LoadUserData();
        }
    }
}
