﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LMS5.Admin
{
    public partial class Form8Reports : Sample
    {
        string connectionString = "Data Source=(localdb)\\localDB_1;" +
                                  "Initial Catalog=LeaveManagementSystem2; Integrated Security=true";

        public Form8Reports()
        {
            InitializeComponent();
            LoadLeaveTypeComboBox();
            LoadDepartmentComboBox();
            LoadEmployeeNameComboBox();
        }

        private void LoadLeaveTypeComboBox()//load data to cmb
        {
            string query = "SELECT LeaveTypeID, LeaveType FROM dbo.LeaveTypes";

            DataTable leaveTypeTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);

                    connection.Open();
                    adapter.Fill(leaveTypeTable);

                    cmbLeaveType.DataSource = leaveTypeTable;
                    cmbLeaveType.DisplayMember = "LeaveType";
                    cmbLeaveType.ValueMember = "LeaveTypeID";

                    cmbLeaveType.SelectedIndex = -1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading leave types: " + ex.Message);
                }
            }
        }

        private void LoadDepartmentComboBox()//load data to cmb
        {
            string query = "SELECT DepartmentID, DepartmentName FROM dbo.Departments";

            DataTable departmentTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);

                    connection.Open();
                    adapter.Fill(departmentTable);

                    cmbDepartments.DataSource = departmentTable;
                    cmbDepartments.DisplayMember = "DepartmentName";
                    cmbDepartments.ValueMember = "DepartmentID";

                    cmbDepartments.SelectedIndex = -1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading departments: " + ex.Message);
                }
            }
        }

        private void LoadEmployeeNameComboBox()//load data to cmb
        {
            string query = "SELECT UserID, FullName FROM dbo.Users";

            DataTable employeeTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);

                    connection.Open();
                    adapter.Fill(employeeTable);

                    cmbEmpName.DataSource = employeeTable;
                    cmbEmpName.DisplayMember = "FullName";
                    cmbEmpName.ValueMember = "UserID";

                    cmbEmpName.SelectedIndex = -1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading employee names: " + ex.Message);
                }
            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            cmbEmpName.SelectedIndex = -1;
            cmbDepartments.SelectedIndex = -1;
            cmbLeaveType.SelectedIndex = -1;
            dtpStart.Value = DateTime.Now;
            dtpEnd.Value = DateTime.Now;

            cmbEmpName.DataSource = null;
            cmbDepartments.DataSource = null;
            cmbLeaveType.DataSource = null;

            LoadLeaveTypeComboBox();
            LoadDepartmentComboBox();
            LoadEmployeeNameComboBox();
        }

        private void btnGetReport_Click(object sender, EventArgs e)
        {
            string query = "SELECT lr.UserID, u.FullName, lt.LeaveType, d.DepartmentName, " +
                           "lr.StartDate, lr.EndDate, lr.Reason, lr.Status " +
                           "FROM LeaveRequests2 lr " +
                           "RIGHT JOIN Users u ON lr.UserID = u.UserID " +  
                           "LEFT JOIN LeaveTypes lt ON lr.LeaveTypeID = lt.LeaveTypeID " +
                           "LEFT JOIN Departments d ON u.DepartmentID = d.DepartmentID " +  
                           "WHERE lr.StartDate >= @StartDate AND lr.EndDate <= @EndDate";

            var parameters = new List<SqlParameter>
    {
        new SqlParameter("@StartDate", dtpStart.Value),
        new SqlParameter("@EndDate", dtpEnd.Value)
    };

            if (cmbLeaveType.SelectedIndex != -1)
            {
                query += " AND lr.LeaveTypeID = @LeaveTypeID";
                parameters.Add(new SqlParameter("@LeaveTypeID", (int)cmbLeaveType.SelectedValue));
            }

            if (cmbDepartments.SelectedIndex != -1)
            {
                query += " AND d.DepartmentID = @DepartmentID";
                parameters.Add(new SqlParameter("@DepartmentID", (int)cmbDepartments.SelectedValue));
            }

            if (cmbEmpName.SelectedIndex != -1)
            {
                query += " AND lr.UserID = @UserID";
                parameters.Add(new SqlParameter("@UserID", (int)cmbEmpName.SelectedValue)); 
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);

                command.Parameters.AddRange(parameters.ToArray());

                try
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable reportData = new DataTable();
                    adapter.Fill(reportData);

                    dgvReport.DataSource = reportData;

                    MessageBox.Show($"Rows returned: {reportData.Rows.Count}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while generating the report: " + ex.Message);
                }
            }
        }
    }
}
