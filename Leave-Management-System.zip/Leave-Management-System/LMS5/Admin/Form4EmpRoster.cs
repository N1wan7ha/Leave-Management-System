﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace LMS5.Admin
{
    public partial class Form4EmpRoster : UserControl
    {
        private string connectionString = "Data Source=(localdb)\\localDB_1;Initial Catalog=LeaveManagementSystem2;Integrated Security=true";
        private int selectedUserId;

        public Form4EmpRoster()
        {
            InitializeComponent();
            LoadRosterData();
            this.dgvRoster.CellClick += new DataGridViewCellEventHandler(this.dgvRoster_CellClick);

        }

        private void LoadRosterData()//load data to dgv
        {
            string query = "SELECT Roster.RosterID, Users.UserID, Users.FullName AS EmployeeName, Roster.StartTime, Roster.EndTime, Roster.DaysOfWeek, Roster.CreatedAt " +
                           "FROM Roster " +
                           "INNER JOIN Users ON Roster.UserID = Users.UserID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();

                    connection.Open();
                    adapter.Fill(dataTable);
                    dgvRoster.DataSource = dataTable; 
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading roster data: " + ex.Message);
                }
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if (selectedUserId == 0)
            {
                MessageBox.Show("Please select an employee to update the roster.");
                return;
            }

            TimeSpan startTime = dtpStart.Value.TimeOfDay; 
            TimeSpan endTime = dtpEnd.Value.TimeOfDay;    

            string daysOfWeek = GetSelectedDays();

            string query = "IF EXISTS (SELECT * FROM Roster WHERE UserID = @UserID) " +
                           "UPDATE Roster SET StartTime = @StartTime, EndTime = @EndTime, DaysOfWeek = @DaysOfWeek " +
                           "WHERE UserID = @UserID " +
                           "ELSE " +
                           "INSERT INTO Roster (UserID, StartTime, EndTime, DaysOfWeek, CreatedAt) " +
                           "VALUES (@UserID, @StartTime, @EndTime, @DaysOfWeek, GETDATE())";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserID", selectedUserId);
                    command.Parameters.AddWithValue("@StartTime", startTime);
                    command.Parameters.AddWithValue("@EndTime", endTime);
                    command.Parameters.AddWithValue("@DaysOfWeek", daysOfWeek);

                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Roster updated successfully!");
                    LoadRosterData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating roster: " + ex.Message);
                }
            }
        }

        private string GetSelectedDays()
        {
            List<string> days = new List<string>();
            if (cbMon.Checked) days.Add("Mon");
            if (cbTue.Checked) days.Add("Tue");
            if (cbWed.Checked) days.Add("Wed");
            if (cbThu.Checked) days.Add("Thu");
            if (cbFri.Checked) days.Add("Fri");
            if (cbSat.Checked) days.Add("Sat");
            if (cbSun.Checked) days.Add("Sun");
            return string.Join(",", days).Trim();
        }


        private void dgvRoster_CellClick(object sender, DataGridViewCellEventArgs e)//pop data when row clicked
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvRoster.Rows[e.RowIndex];
                selectedUserId = Convert.ToInt32(row.Cells["UserID"].Value); 

                dtpStart.Value = DateTime.Today.Add((TimeSpan)row.Cells["StartTime"].Value);
                dtpEnd.Value = DateTime.Today.Add((TimeSpan)row.Cells["EndTime"].Value);

                string[] days = row.Cells["DaysOfWeek"].Value.ToString().Split(',');
                cbMon.Checked = days.Contains("Mon");
                cbTue.Checked = days.Contains("Tue");
                cbWed.Checked = days.Contains("Wed");
                cbThu.Checked = days.Contains("Thu");
                cbFri.Checked = days.Contains("Fri");
                cbSat.Checked = days.Contains("Sat");
                cbSun.Checked = days.Contains("Sun");
            }
        }

        private void btnSubmit_Click_1(object sender, EventArgs e)
        {
            
                if (selectedUserId == 0)
                {
                    MessageBox.Show("Please select an employee to update the roster.");
                    return;
                }

                TimeSpan startTime = dtpStart.Value.TimeOfDay;
                TimeSpan endTime = dtpEnd.Value.TimeOfDay;     

                string daysOfWeek = GetSelectedDays();

                string query = "IF EXISTS (SELECT * FROM Roster WHERE UserID = @UserID) " +
                               "UPDATE Roster SET StartTime = @StartTime, EndTime = @EndTime, DaysOfWeek = @DaysOfWeek " +
                               "WHERE UserID = @UserID " +
                               "ELSE " +
                               "INSERT INTO Roster (UserID, StartTime, EndTime, DaysOfWeek, CreatedAt) " +
                               "VALUES (@UserID, @StartTime, @EndTime, @DaysOfWeek, GETDATE())";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@UserID", selectedUserId);
                        command.Parameters.AddWithValue("@StartTime", startTime);
                        command.Parameters.AddWithValue("@EndTime", endTime);
                        command.Parameters.AddWithValue("@DaysOfWeek", daysOfWeek);

                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Roster updated successfully!");
                        LoadRosterData(); 
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating roster: " + ex.Message);
                    }
                }
            

        }
    }
}
