﻿namespace LMS5.Admin
{
    partial class Form4EmpRoster
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dtpStart = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.dtpEnd = new Guna.UI2.WinForms.Guna2DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbSun = new Guna.UI2.WinForms.Guna2CheckBox();
            this.cbSat = new Guna.UI2.WinForms.Guna2CheckBox();
            this.cbFri = new Guna.UI2.WinForms.Guna2CheckBox();
            this.cbThu = new Guna.UI2.WinForms.Guna2CheckBox();
            this.cbWed = new Guna.UI2.WinForms.Guna2CheckBox();
            this.cbTue = new Guna.UI2.WinForms.Guna2CheckBox();
            this.cbMon = new Guna.UI2.WinForms.Guna2CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnSubmit = new Guna.UI2.WinForms.Guna2Button();
            this.dgvRoster = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRoster)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(19, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 19);
            this.label4.TabIndex = 38;
            this.label4.Text = "Employee Roster";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(153, 34);
            this.label1.TabIndex = 37;
            this.label1.Text = "Employees";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 310);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 19);
            this.label2.TabIndex = 38;
            this.label2.Text = "Edit Roster";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 336);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 16);
            this.label3.TabIndex = 38;
            this.label3.Text = "Selected Employee: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(16, 31);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 14);
            this.label5.TabIndex = 38;
            this.label5.Text = "Start Time: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(16, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 14);
            this.label6.TabIndex = 38;
            this.label6.Text = "End Time: ";
            // 
            // dtpStart
            // 
            this.dtpStart.AutoRoundedCorners = true;
            this.dtpStart.BorderRadius = 16;
            this.dtpStart.Checked = true;
            this.dtpStart.CustomFormat = "";
            this.dtpStart.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.dtpStart.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtpStart.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpStart.Location = new System.Drawing.Point(99, 20);
            this.dtpStart.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpStart.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(130, 34);
            this.dtpStart.TabIndex = 40;
            this.dtpStart.Value = new System.DateTime(2024, 10, 11, 16, 8, 38, 803);
            // 
            // dtpEnd
            // 
            this.dtpEnd.AutoRoundedCorners = true;
            this.dtpEnd.BorderRadius = 16;
            this.dtpEnd.Checked = true;
            this.dtpEnd.CustomFormat = "";
            this.dtpEnd.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.dtpEnd.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtpEnd.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpEnd.Location = new System.Drawing.Point(99, 60);
            this.dtpEnd.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.dtpEnd.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(130, 34);
            this.dtpEnd.TabIndex = 40;
            this.dtpEnd.Value = new System.DateTime(2024, 10, 11, 16, 8, 38, 803);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.dtpEnd);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.dtpStart);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(23, 355);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(891, 118);
            this.groupBox1.TabIndex = 41;
            this.groupBox1.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbSun);
            this.groupBox2.Controls.Add(this.cbSat);
            this.groupBox2.Controls.Add(this.cbFri);
            this.groupBox2.Controls.Add(this.cbThu);
            this.groupBox2.Controls.Add(this.cbWed);
            this.groupBox2.Controls.Add(this.cbTue);
            this.groupBox2.Controls.Add(this.cbMon);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(313, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(578, 118);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            // 
            // cbSun
            // 
            this.cbSun.AutoSize = true;
            this.cbSun.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbSun.CheckedState.BorderRadius = 0;
            this.cbSun.CheckedState.BorderThickness = 0;
            this.cbSun.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbSun.Location = new System.Drawing.Point(487, 60);
            this.cbSun.Name = "cbSun";
            this.cbSun.Size = new System.Drawing.Size(62, 17);
            this.cbSun.TabIndex = 43;
            this.cbSun.Text = "Sunday";
            this.cbSun.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbSun.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbSun.UncheckedState.BorderRadius = 0;
            this.cbSun.UncheckedState.BorderThickness = 0;
            this.cbSun.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // cbSat
            // 
            this.cbSat.AutoSize = true;
            this.cbSat.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbSat.CheckedState.BorderRadius = 0;
            this.cbSat.CheckedState.BorderThickness = 0;
            this.cbSat.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbSat.Location = new System.Drawing.Point(414, 60);
            this.cbSat.Name = "cbSat";
            this.cbSat.Size = new System.Drawing.Size(68, 17);
            this.cbSat.TabIndex = 43;
            this.cbSat.Text = "Saturday";
            this.cbSat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbSat.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbSat.UncheckedState.BorderRadius = 0;
            this.cbSat.UncheckedState.BorderThickness = 0;
            this.cbSat.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // cbFri
            // 
            this.cbFri.AutoSize = true;
            this.cbFri.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbFri.CheckedState.BorderRadius = 0;
            this.cbFri.CheckedState.BorderThickness = 0;
            this.cbFri.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbFri.Location = new System.Drawing.Point(341, 60);
            this.cbFri.Name = "cbFri";
            this.cbFri.Size = new System.Drawing.Size(54, 17);
            this.cbFri.TabIndex = 43;
            this.cbFri.Text = "Friday";
            this.cbFri.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbFri.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbFri.UncheckedState.BorderRadius = 0;
            this.cbFri.UncheckedState.BorderThickness = 0;
            this.cbFri.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // cbThu
            // 
            this.cbThu.AutoSize = true;
            this.cbThu.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbThu.CheckedState.BorderRadius = 0;
            this.cbThu.CheckedState.BorderThickness = 0;
            this.cbThu.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbThu.Location = new System.Drawing.Point(268, 60);
            this.cbThu.Name = "cbThu";
            this.cbThu.Size = new System.Drawing.Size(70, 17);
            this.cbThu.TabIndex = 43;
            this.cbThu.Text = "Thursday";
            this.cbThu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbThu.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbThu.UncheckedState.BorderRadius = 0;
            this.cbThu.UncheckedState.BorderThickness = 0;
            this.cbThu.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // cbWed
            // 
            this.cbWed.AutoSize = true;
            this.cbWed.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbWed.CheckedState.BorderRadius = 0;
            this.cbWed.CheckedState.BorderThickness = 0;
            this.cbWed.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbWed.Location = new System.Drawing.Point(181, 60);
            this.cbWed.Name = "cbWed";
            this.cbWed.Size = new System.Drawing.Size(83, 17);
            this.cbWed.TabIndex = 43;
            this.cbWed.Text = "Wednesday";
            this.cbWed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbWed.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbWed.UncheckedState.BorderRadius = 0;
            this.cbWed.UncheckedState.BorderThickness = 0;
            this.cbWed.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // cbTue
            // 
            this.cbTue.AutoSize = true;
            this.cbTue.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbTue.CheckedState.BorderRadius = 0;
            this.cbTue.CheckedState.BorderThickness = 0;
            this.cbTue.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbTue.Location = new System.Drawing.Point(108, 60);
            this.cbTue.Name = "cbTue";
            this.cbTue.Size = new System.Drawing.Size(67, 17);
            this.cbTue.TabIndex = 43;
            this.cbTue.Text = "Tuesday";
            this.cbTue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbTue.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbTue.UncheckedState.BorderRadius = 0;
            this.cbTue.UncheckedState.BorderThickness = 0;
            this.cbTue.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // cbMon
            // 
            this.cbMon.AutoSize = true;
            this.cbMon.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbMon.CheckedState.BorderRadius = 0;
            this.cbMon.CheckedState.BorderThickness = 0;
            this.cbMon.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.cbMon.Location = new System.Drawing.Point(35, 60);
            this.cbMon.Name = "cbMon";
            this.cbMon.Size = new System.Drawing.Size(64, 17);
            this.cbMon.TabIndex = 43;
            this.cbMon.Text = "Monday";
            this.cbMon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbMon.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.cbMon.UncheckedState.BorderRadius = 0;
            this.cbMon.UncheckedState.BorderThickness = 0;
            this.cbMon.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Days of the Week:";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSubmit.AutoRoundedCorners = true;
            this.btnSubmit.BorderRadius = 15;
            this.btnSubmit.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnSubmit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnSubmit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnSubmit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnSubmit.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnSubmit.ForeColor = System.Drawing.Color.White;
            this.btnSubmit.Location = new System.Drawing.Point(23, 495);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(90, 33);
            this.btnSubmit.TabIndex = 42;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click_1);
            // 
            // dgvRoster
            // 
            this.dgvRoster.AllowUserToAddRows = false;
            this.dgvRoster.AllowUserToDeleteRows = false;
            this.dgvRoster.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvRoster.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRoster.BackgroundColor = System.Drawing.Color.White;
            this.dgvRoster.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvRoster.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRoster.Location = new System.Drawing.Point(23, 98);
            this.dgvRoster.Name = "dgvRoster";
            this.dgvRoster.ReadOnly = true;
            this.dgvRoster.Size = new System.Drawing.Size(957, 150);
            this.dgvRoster.TabIndex = 43;
            // 
            // Form4EmpRoster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.dgvRoster);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Name = "Form4EmpRoster";
            this.Size = new System.Drawing.Size(1070, 550);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRoster)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpStart;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpEnd;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private Guna.UI2.WinForms.Guna2CheckBox cbSun;
        private Guna.UI2.WinForms.Guna2CheckBox cbSat;
        private Guna.UI2.WinForms.Guna2CheckBox cbFri;
        private Guna.UI2.WinForms.Guna2CheckBox cbThu;
        private Guna.UI2.WinForms.Guna2CheckBox cbWed;
        private Guna.UI2.WinForms.Guna2CheckBox cbTue;
        private Guna.UI2.WinForms.Guna2CheckBox cbMon;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2Button btnSubmit;
        private System.Windows.Forms.DataGridView dgvRoster;
    }
}
