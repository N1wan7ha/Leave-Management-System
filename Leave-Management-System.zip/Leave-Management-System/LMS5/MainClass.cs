﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LMS5
{
    internal class MainClass
    {
        private string connectionString = "Data Source=(localdb)\\localDB_1;Initial Catalog=LeaveManagementSystem2;Integrated Security=true";

        public int LoadPendingReqCount()
        {
            int pendingCount = 0;
            string query = "SELECT COUNT(*) FROM LeaveRequests2 WHERE Status = 'Pending'";
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    pendingCount = (int)cmd.ExecuteScalar();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading user count: " + ex.Message);

            }
            return pendingCount;
        }

        public int LoadApprovedReqCount()
        {
            int approvedCount = 0;
            string query = "SELECT COUNT(*) FROM LeaveRequests2 WHERE Status = 'Approved'";
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    approvedCount = (int)cmd.ExecuteScalar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading user count: " + ex.Message);

            }
            return approvedCount;
        }

        public int LoadUserCount()
        {
            int userCount = 0;
            string query = "SELECT COUNT(*) AS TotalEmployees FROM Users";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    userCount = (int)cmd.ExecuteScalar();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading user count: " + ex.Message);
            }
            return userCount;
        }

        public int LoadLeaveTypeCount()
        {
            int leaveTypeCount = 0;
            string query = "SELECT COUNT(*) AS LeaveTypeCount FROM LeaveTypes;";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    leaveTypeCount = (int)cmd.ExecuteScalar();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading user count: " + ex.Message);
            }
            return leaveTypeCount;
        }

        public int LoadDepCount()
        {
            int DepCount = 0;
            string query = "SELECT COUNT(*) AS DepCount FROM Departments;";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    DepCount = (int)cmd.ExecuteScalar();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading user count: " + ex.Message);
            }
            return DepCount;
        }

        public int LoadRejectedReqCount()
        {
            int rejectCount = 0;
            string query = "SELECT COUNT(*) FROM LeaveRequests2 WHERE Status = 'Rejected'";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    rejectCount = (int)cmd.ExecuteScalar();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading user count: " + ex.Message);
            }
            return rejectCount;
        }


    }
}
