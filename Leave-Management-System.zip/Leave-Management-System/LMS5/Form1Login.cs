﻿using LMS5.Employee;
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace LMS5
{
    public partial class Form1Login : Sample
    {
        string connectionString = "Data Source=(localdb)\\localDB_1;" +
                          "Initial Catalog=LeaveManagementSystem2; Integrated Security=true";


        public Form1Login()
        {
            InitializeComponent();
            txtPassword.PasswordChar = '*';
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string sqlCommand = "SELECT UserID, Role FROM Users WHERE " +
                                "EmployeeNumber = @EmployeeNumber AND " +
                                "Password COLLATE Latin1_General_BIN = @Password"; //to validate case-sensitive
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand command = new SqlCommand(sqlCommand, connection);
                    command.Parameters.AddWithValue("@EmployeeNumber", txtEmpNum.Text);
                    command.Parameters.AddWithValue("@Password", txtPassword.Text);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read()) //validating user's role admin or user?
                    {
                        int userId = Convert.ToInt32(reader["UserID"]);
                        string role = reader["Role"].ToString();
                        UserSession.LoggedInUserID = userId;

                        if (role == "Admin")
                        {
                            Form2Main form2Main = new Form2Main();
                            form2Main.Show();
                            this.Hide();
                        }
                        else if (role == "User")
                        {
                            Form1EmpMain empMain = new Form1EmpMain();
                            empMain.Show();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Access denied.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid employee number or password.");
                    }
                    reader.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }


        private void guna2ControlBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
